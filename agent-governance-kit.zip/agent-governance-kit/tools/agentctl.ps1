param(
  [Parameter(ValueFromRemainingArguments=$true)]
  [string[]]$Args
)
python tools/agentctl.py @Args
