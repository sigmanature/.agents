---
name: wechat-wxapkg-and-apk-batch-tools
description: >
  Use this skill whenever the user asks to 批量下载微信小程序包(wxapkg) from a URL list (often with Cookie/Token headers)
  OR asks to 批量安装一批 APK 到一台或多台 Android 设备 (adb install). This skill provides a repeatable workflow and
  repo-local CLI scripts that generate manifests/logs for auditing and retry.
---

## What this skill does
This skill wraps two standalone CLI scripts in this repo:

1) **Batch download wxapkg** (WeChat mini-program packages) from a `urls.txt` list, optionally sending auth headers from `headers.json`.
   - Tool: [`scripts/wxapkg_batch_download.py`](scripts/wxapkg_batch_download.py:1)

2) **Batch install APKs** from a directory to one or more Android devices.
   - Tool: [`scripts/apk_batch_install.py`](scripts/apk_batch_install.py:1)

The scripts always generate structured outputs:
- wxapkg: `manifest.jsonl` + `failed_urls.txt`
- apk install: `install_log.jsonl` + `installed_packages.txt` + `failed_apks.txt`

## Preconditions / assumptions
- For wxapkg download: URLs are directly downloadable; if auth is needed, user can provide `headers.json` (Cookie/Token/etc.).
- For APK install: `adb` must be available in PATH and devices must be in `device` state (`adb devices`).

## Workflow A — Batch download wxapkg
### 1) Ask for inputs
You need:
- Path to `urls.txt` (one URL per line; allow blank lines and `#` comments)
- Optional `headers.json` (JSON object/dict) applied to all requests
- Optional output directory path (otherwise use default)

If user has no file yet, instruct them to create it.

### 2) Run the downloader
Command:
- [`scripts/wxapkg_batch_download.py`](scripts/wxapkg_batch_download.py:1)

Example:
```bash
python3 scripts/wxapkg_batch_download.py \
  --urls ./data/urls.txt \
  --headers-json ./data/headers.json \
  --output-dir ./output/wxapkg_run_001 \
  --workers 6 \
  --retries 2
```

### 3) Verify outputs
Check in output dir:
- `files/` contains downloaded binaries
- `manifest.jsonl` exists and has one line per URL
- `failed_urls.txt` lists failures for retry

### 4) Troubleshooting
- HTTP 401/403: headers are missing/expired (Cookie/Token)
- HTTP 404: URL stale
- HTTP 429/5xx: increase retries/backoff, reduce workers

## Workflow B — Batch install APKs
### 1) Ask for inputs
You need:
- Path to APK directory containing `*.apk`
- Optional device serial list
  - If not provided, tool auto-detects via `adb devices`
- Optional output directory

### 2) Run the installer
Command:
- [`scripts/apk_batch_install.py`](scripts/apk_batch_install.py:1)

Example (auto-detect devices):
```bash
python3 scripts/apk_batch_install.py ./apks --output-dir ./output/apk_install_run_001
```

Example (specific devices):
```bash
python3 scripts/apk_batch_install.py ./apks \
  --serial ABC123 \
  --serial DEF456 \
  --output-dir ./output/apk_install_run_002
```

### 3) Verify outputs
In output dir:
- `install_log.jsonl` has per-device results
- `installed_packages.txt` lists APKs that succeeded on *all* devices
- `failed_apks.txt` lists APK filenames that failed on *any* device

### 4) Troubleshooting
- No devices found: `adb devices` shows none in `device` state (unauthorized/offline)
- `INSTALL_FAILED_*`: inspect `install_log.jsonl` stderr; common causes are version downgrade, signature mismatch, low storage

## Reporting format (when you run the scripts)
After running either workflow, summarize:
- Inputs (paths, number of URLs/APKs, device serials)
- Output directory
- Success/failure counts
- Where the manifest/log files are
