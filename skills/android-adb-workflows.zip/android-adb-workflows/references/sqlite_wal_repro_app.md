# SQLite WAL checkpoint repro app (Instrumentation)

This note documents how to run the **Java/Kotlin Instrumentation** repro app:
`~/learn_os/android/sqlite_wal_checkpoint_repro_app/`

Goal:
- reproduce **WAL + explicit checkpoint** writeback patterns under **fscrypt app data path**
- detect first corruption quickly (`PRAGMA quick_check`)
- snapshot `db / db-wal / db-shm` at first failure
- produce time-aligned logs for Perfetto (`elapsedRealtimeNanos`)

## Build on host

The project uses Gradle + Android Gradle Plugin, requiring:
- JDK installed (`java` available)
- Android SDK installed (`ANDROID_HOME` or `sdk.dir` in `local.properties`)
- network access for dependency downloads (first time)

```bash
cd /home/nzzhao/learn_os/android/sqlite_wal_checkpoint_repro_app
./gradlew :app:assembleDebug :app:assembleAndroidTest
```

## Install on device

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk
```

## Run on device

Baseline (single writer + checker, checkpoint every loop):

```bash
adb shell am instrument -w -r \
  -e seconds 300 \
  -e checkpoint TRUNCATE \
  -e synchronous FULL \
  -e blobBytes 4096 \
  -e updatesPerTxn 200 \
  -e rows 2048 \
  -e checkEvery 1 \
  -e patternSample 10 \
  com.learnos.sqlitewalrepro.test/androidx.test.runner.AndroidJUnitRunner
```

More stress:

```bash
adb shell am instrument -w -r \
  -e seconds 600 \
  -e writers 2 \
  -e readers 2 \
  -e checkpoint TRUNCATE \
  -e checkEvery 1 \
  com.learnos.sqlitewalrepro.test/androidx.test.runner.AndroidJUnitRunner
```

## How corruption is detected (golden criteria)

The app treats **either** as failure:
- `PRAGMA quick_check` returns non-`ok` (SQLite internal consistency)
- pattern check detects `crc_mismatch` for sampled rows (semantic corruption)

On first failure it snapshots:
- `repro.db`
- `repro.db-wal`
- `repro.db-shm`

to:
`/sdcard/Android/data/com.learnos.sqlitewalrepro/files/wal_repro_artifacts/<run>/<iter_...>/`

Pull:

```bash
adb pull /sdcard/Android/data/com.learnos.sqlitewalrepro/files/wal_repro_artifacts ./wal_repro_artifacts
```

## Log alignment with Perfetto

Logcat tag: `WalRepro`

Each phase prints `ts_mono_ns=SystemClock.elapsedRealtimeNanos()` which aligns well to
Perfetto ftrace timestamps (since-boot semantics).

