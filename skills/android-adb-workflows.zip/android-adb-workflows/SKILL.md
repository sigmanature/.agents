---
name: android-adb-workflows
description: generate correct, runnable adb commands and host-side bash scripts for android devices (pixel and others), including monkey automation with repeatable parameters, fast package name discovery, and log/artifact collection (logcat, dumpsys, dropbox, bugreport, tombstones/anr) with root-aware handling (su -c, magisk). use when a user asks for adb/adb shell commands, android monkey tests, package names, pulling crash artifacts, or avoiding common root/quoting/host-vs-device pitfalls.
---

# Android ADB Workflows

This skill is a **router + toolkit**:

- **General ADB execution rules** (host vs device, `su -c`, quoting/redirection, root-only artifacts): see `references/adb_execution_reference.md`.
- **Monkey automation + log collection** (repeatable run, timestamped folder): use `scripts/run_monkey_and_collect_logs.sh`.
- **Package name discovery** (list/search/current foreground app): use `scripts/adb_pkg.sh`.

## Core rule (do not violate)
Do **not** blindly wrap everything in `adb shell`. Pick the correct layer:

- **Host-side adb subcommands**: `adb pull/push`, `adb logcat`, `adb bugreport`, `adb exec-out`, `adb install`, `adb uninstall`.
- **Device-side shell commands**: `adb shell pm ...`, `adb shell dumpsys ...`, `adb shell monkey ...`, `adb shell getprop ...`.
- **Root on device**: only when needed, use `adb shell su -c '<device command>'` (and `su -c 'sh -c "..."'` for pipes/redirection/globs).

When the user’s question touches root or complex quoting, **load** `references/adb_execution_reference.md` before responding.

## Output contract (what to send in chat)
Always provide:

1) A **ready-to-run** command (or short script snippet) the user can copy/paste.
2) Any **defaults** you assumed (events/throttle/seed/etc.) spelled out explicitly.
3) Where outputs land (files/folders) and what to inspect.

Avoid long explanations unless the user asks.

## Routing guide

### A) User asks to run Monkey / fuzz UI / random clicks / stress test
Use the shipped script:

```bash
chmod +x scripts/run_monkey_and_collect_logs.sh
./scripts/run_monkey_and_collect_logs.sh --package <pkg.name>
```
If one device,directly use the only device.
If multi-device, include `--serial <SERIAL>`.

**Defaults (if user didn’t specify):**
- `--events 50000`
- `--throttle 75`
- `--seed <generated and printed by script>`
- native crashes are ignored by default so monkey keeps running; pass `--abort-on-native-crash` only when you explicitly want crash-stop semantics

After generating the command, list key output files:
- `logcat_all_threadtime.txt`
- `monkey_stdout.txt`, `monkey_stderr.txt`
- `dumpsys_activity_start.txt`, `dumpsys_activity_end.txt`
- `dumpsys_meminfo_start.txt`, `dumpsys_meminfo_end.txt`
- `dumpsys_dropbox_print.txt`
- `device_artifacts/` (only if `su` available)
- `summary.txt`

If the user asks to stop monkey quickly, use the shipped stop script:

```bash
chmod +x scripts/stop_monkey_now.sh
./scripts/stop_monkey_now.sh --serial <SERIAL>
```

Notes to state explicitly:
- monkey runs on the device; unplugging USB does not reliably stop it
- `stop_monkey_now.sh` kills `com.android.commands.monkey` on device and sends `KEYCODE_HOME`
- if the user also launched a host wrapper such as `run_experiment.py`, killing device monkey stops the workload but the host wrapper may still continue sampling until its own exit logic runs

### B) User asks “how do I quickly get package names?” or run in try mode
Use `scripts/adb_pkg.sh`.

Examples:

```bash
chmod +x scripts/adb_pkg.sh
./scripts/adb_pkg.sh list
./scripts/adb_pkg.sh --filter wechat list
./scripts/adb_pkg.sh current
```
- User may explictly ask to run in try mode.
### C) User asks about pulling tombstones / ANR traces / dropbox, or “root pitfalls”
Load `references/adb_execution_reference.md` and follow its recommended patterns (especially `su -c` + `sh -c` nesting and safe artifact pulling).

### D) User asks to uninstall then reinstall an app (APK in hand)
Use the shipped reinstall helper:

```bash
chmod +x scripts/adb_reinstall_apk.sh
./scripts/adb_reinstall_apk.sh --serial <SERIAL> --package <pkg.name> --apk <path.apk> --launch
```

If the user doesn’t know `<pkg.name>`, use `scripts/adb_pkg.sh` to discover it first.

If the user asks to reinstall the common 4-app set (WeChat/UC/Douyin/Huoshan), use:

```bash
chmod +x scripts/adb_reinstall_wechat_douyin_uc_huoshan.sh
./scripts/adb_reinstall_wechat_douyin_uc_huoshan.sh --serial <SERIAL> --base-dir <DIR_WITH_APKS> --allow-downgrade --grant --launch
```

### E) User asks to locate app SQLite DB files / WAL/SHM / “where is the database?”
Load `references/sqlite_db_discovery.md` (and `references/adb_execution_reference.md` if quoting gets complex).

### F) User asks what UI actions can trigger SQLite writes in third-party apps
Load `references/sqlite_write_triggers.md`.

### G) User asks for a script to generate SQLite write load (Settings / Launcher)

Use one of the shipped helpers:

```bash
chmod +x scripts/sqlite_write_load_settingsprovider.sh
./scripts/sqlite_write_load_settingsprovider.sh --seconds 300 --sleep-ms 200
```

```bash
chmod +x scripts/sqlite_write_load_launcher_monkey.sh
./scripts/sqlite_write_load_launcher_monkey.sh --events 20000 --throttle 60
```

### H) User asks to reproduce SQLite WAL + checkpoint IO and capture syscall/fs traces

Use the shipped WAL checkpoint repro + perfetto capture helper:

```bash
chmod +x scripts/sqlite_wal_checkpoint_repro_and_trace.sh
./scripts/sqlite_wal_checkpoint_repro_and_trace.sh --seconds 300 --checkpoint TRUNCATE --sync FULL
```

If `sqlite3` is missing on device, the script prints push instructions.

### I) User asks to reproduce WAL corruption inside fscrypt app sandbox

Use the debuggable repro app runner instructions:
- `references/sqlite_wal_repro_app.md`

## Included resources
- `scripts/run_monkey_and_collect_logs.sh`
- `scripts/stop_monkey_now.sh`
- `scripts/adb_pkg.sh`
- `scripts/adb_reinstall_apk.sh` (uninstall + reinstall 1 APK)
- `scripts/adb_reinstall_wechat_douyin_uc_huoshan.sh` (uninstall + reinstall WeChat/UC/Douyin/Huoshan)
- `scripts/logcat_sig_diff.py` (offline: compare 2 `logcat_all.txt` files)
- `scripts/logcat_storage_triage.py` (offline: scan 1 `logcat_all.txt` for storage-ish signals + top crashes)
- `scripts/lf_unaligned_rw_smoke.sh` (large-folio + encrypted dir unaligned R/W smoke test)
- `scripts/pkgxml_install_reboot_capture.sh` (install 1 APK -> reboot -> capture pm_critical packages.xml EINVAL evidence)
- `scripts/adb_helpers.sh` (optional helpers for scripts; safe quoting patterns)
- `scripts/sqlite_write_load_settingsprovider.sh` (deterministic SettingsProvider write load, no UI)
- `scripts/sqlite_write_load_launcher_monkey.sh` (launcher UI churn via monkey; practical but not strictly deterministic)
- `scripts/sqlite_wal_checkpoint_repro_and_trace.sh` (create WAL DB -> loop write/commit/checkpoint -> perfetto trace syscalls+f2fs+block)
- `references/adb_execution_reference.md`
- `references/sqlite_db_discovery.md` (root: enumerate app DB/WAL/SHM files)
- `references/sqlite_write_triggers.md` (UI actions that commonly cause SQLite writes)
- `references/sqlite_wal_repro_app.md` (run the debuggable WAL+checkpoint repro app via `am instrument`)
- `references/monkey_flags.md`
- `references/pm_critical_packages_xml_einval.md` (PackageManager `packages.xml` `EINVAL` triage)
- `references/large_folio_unaligned_rw_smoke.md` (how to run the unaligned R/W test)
- `references/logcat_offline_compare.md` (offline: diff two devices’ logcat captures)
- `references/logcat_storage_triage.md` (offline: decide “storage regression vs app/dex/classloader” quickly)
- `references/dex_classnotfound_storage_triage.md` (CNFE widespread after reboot: map crash->apk->oat/vdex + storage signals + safe recovery)
- `references/native_lib_file_inspect.md` (inspect `/data/app/.../lib/arm64/*.so` via adb/su)
- `references/app_reinstall_workflow.md` (quick uninstall/reinstall checklist)
